// ex. 1
// describe("Multiplicação ", function(){
//     it("Resultado: ", function(){

//         let a = 2;
//         let b = 4;
//         let c = 6;
        
//         expect(multiplicacao(a, b, c)).toBe(48);
//     })
// }
// )

// ex. 2
// describe ("Divisão: ", function(){
//     it("Resultado: ", function(){


//         expect(divisao(6,2)).toBe(3)
//     })
  
// })

//ex. 3 
// describe("Celsius para Fahrenheit:", function(){
//     it("Resultado: ", function(){

//         expect(celsiusFahrenheit(0)).toBe(32)
//     })
// })

// describe("Fahrenheit para Celsius:", function(){
//     it("Resultado: ", function(){

//         expect(fahrenheitCelsius(32)).toBe(0)
//     })
// })


//ex.4 
// describe("Calcular Média: ", function(){
//     it("Resultado: ", function(){

//         expect(calcularMedia(10,20,30)).toBe(20)
//     })
// })

//ex.5
// describe("Contar Caracteres: ", function(){
//     it("Resultado:", function(){
//         expect(contarCaracteres("amar")).toBe(4)
//     })
// })

//ex.6
// describe("Operações:", function(){
//     it("Soma: ", function(){
//         expect(operacoes(10, 20, "+")).toBe(30)
//     })

//     it("Subtração: ", function(){
//         expect(operacoes(10, 10, "-")).toBe(0)
//     })

//     it("Multiplicação: ", function(){
//         expect(operacoes(10, 20, "*")).toBe(200)
//     })

//     it("Divisão: ", function(){
//         expect(operacoes(10, 5, "/")).toBe(2)
//     })

// })